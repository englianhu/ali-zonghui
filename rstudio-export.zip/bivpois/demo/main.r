

#source( system.file('demo','main2.r',package='bivpois'),  echo=FALSE)

source( 'f:/bivpois/demo/main2.r',  echo=FALSE)
